# Image Morph Slider

2枚の画像をアップロードし、クロスフェード/ワイプで徐々に変化させるWebアプリ。  
Vite + React + Tailwind。GitHub PagesにActionsで自動デプロイできます。

## 開発

```bash
npm ci
npm run dev
```

## ビルド

```bash
npm run build
```

## デプロイ (GitHub Pages)

- `.github/workflows/deploy.yml` を用意済み（mainにpushで自動デプロイ）
- プロジェクトページの場合: `vite.config.ts` の `base` を `/<リポジトリ名>/` に変更
- リポジトリの Settings → Pages で **Source: GitHub Actions** を選択
