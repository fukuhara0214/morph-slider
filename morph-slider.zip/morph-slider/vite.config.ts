import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // GitHub Pagesのプロジェクトページとして公開する場合はベースパスをリポジトリ名に変更してください。
  // 例) repoが `morph-slider` なら '/morph-slider/'。
  // ユーザー/組織ページ(`<username>.github.io`)で公開するなら '/' のままでOK。
  base: '/morph-slider/',
})
