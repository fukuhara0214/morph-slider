import React, { useEffect, useMemo, useRef, useState } from "react";

/**
 * Image Morph Slider App
 * - 2枚の画像をアップロード
 * - モード切替: Crossfade(不透明度) / Wipe(スライダーで切り分け)
 * - 向き切替: 横(左右) / 縦(上下)
 * - 画像上で直接ドラッグしてもスライド可能（タッチ対応）
 * - Tailwindのみで1ファイル完結
 */
export default function App() {
  const [img1, setImg1] = useState<string | null>(null);
  const [img2, setImg2] = useState<string | null>(null);
  const [mode, setMode] = useState<"crossfade" | "wipe">("crossfade");
  const [orientation, setOrientation] = useState<"horizontal" | "vertical">(
    "horizontal"
  );
  const [reveal, setReveal] = useState<number>(50); // 0..100
  const [dragging, setDragging] = useState(false);

  const containerRef = useRef<HTMLDivElement | null>(null);

  // 画像URLのメモリ解放
  useEffect(() => {
    return () => {
      if (img1?.startsWith("blob:")) URL.revokeObjectURL(img1);
      if (img2?.startsWith("blob:")) URL.revokeObjectURL(img2);
    };
  }, [img1, img2]);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>, setUrl: any) => {
    const f = e.target.files?.[0];
    if (f) setUrl(URL.createObjectURL(f));
  };

  const clamp = (n: number) => Math.min(100, Math.max(0, n));

  const updateFromPointer = (clientX: number, clientY: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    let p = reveal;
    if (orientation === "horizontal") {
      p = ((clientX - rect.left) / rect.width) * 100;
    } else {
      // 上に行くほど数値が大きくなる（下→上）
      p = ((rect.bottom - clientY) / rect.height) * 100;
    }
    setReveal(clamp(p));
  };

  const onPointerDown: React.PointerEventHandler<HTMLDivElement> = (e) => {
    setDragging(true);
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    updateFromPointer(e.clientX, e.clientY);
  };
  const onPointerMove: React.PointerEventHandler<HTMLDivElement> = (e) => {
    if (!dragging) return;
    updateFromPointer(e.clientX, e.clientY);
  };
  const onPointerUp: React.PointerEventHandler<HTMLDivElement> = (e) => {
    setDragging(false);
    (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
  };

  const hasBoth = Boolean(img1 && img2);

  // wipe用: オーバーレイラッパーの幅/高さ
  const wipeOverlayStyle = useMemo<React.CSSProperties>(() => {
    if (mode !== "wipe") return {};
    if (orientation === "horizontal") {
      return { width: `${reveal}%`, height: "100%" };
    }
    // 縦: 下から上へreveal%
    return { height: `${reveal}%`, width: "100%", bottom: 0 };
  }, [mode, orientation, reveal]);

  // wipe用: 仕切り線/ハンドル位置
  const dividerPosStyle = useMemo<React.CSSProperties>(() => {
    if (orientation === "horizontal") {
      return { left: `calc(${reveal}% - 1px)`, top: 0, bottom: 0 };
    }
    return { top: `calc(${100 - reveal}% - 1px)`, left: 0, right: 0 };
  }, [orientation, reveal]);

  const handlePosStyle = useMemo<React.CSSProperties>(() => {
    if (orientation === "horizontal") {
      return {
        left: `calc(${reveal}% - 14px)`,
        top: "50%",
        transform: "translateY(-50%)",
      };
    }
    return {
      top: `calc(${100 - reveal}% - 14px)`,
      left: "50%",
      transform: "translateX(-50%)",
    };
  }, [orientation, reveal]);

  return (
    <div className="min-h-screen w-full bg-neutral-50 text-neutral-800 p-4 md:p-8">
      <div className="mx-auto max-w-5xl">
        <header className="mb-6 flex items-center justify-between gap-4">
          <h1 className="text-2xl md:text-3xl font-bold">Image Morph Slider</h1>
          <a
            href="https://opensource.org/licenses/MIT"
            target="_blank"
            rel="noreferrer"
            className="text-sm text-neutral-500 hover:text-neutral-700"
          >
            MIT License
          </a>
        </header>

        {/* コントロール */}
        <section className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-1 p-4 bg-white rounded-2xl shadow-sm border">
            <p className="mb-2 text-sm font-semibold">画像アップロード</p>
            <label className="block mb-3">
              <span className="text-xs text-neutral-600">画像A</span>
              <input
                type="file"
                accept="image/*"
                className="mt-1 block w-full text-sm"
                onChange={(e) => onFile(e, setImg1)}
              />
            </label>
            <label className="block">
              <span className="text-xs text-neutral-600">画像B</span>
              <input
                type="file"
                accept="image/*"
                className="mt-1 block w-full text-sm"
                onChange={(e) => onFile(e, setImg2)}
              />
            </label>
            <p className="mt-3 text-xs text-neutral-500">
              同じアスペクト比の画像がおすすめです。
            </p>
          </div>

          <div className="col-span-1 p-4 bg白 rounded-2xl shadow-sm border">
            <p className="mb-2 text-sm font-semibold">モード</p>
            <div className="inline-flex rounded-xl overflow-hidden border">
              <button
                className={`px-3 py-2 text-sm ${mode === "crossfade" ? "bg-neutral-900 text-white" : "bg-white"}`}
                onClick={() => setMode("crossfade")}
              >
                Crossfade（不透明度）
              </button>
              <button
                className={`px-3 py-2 text-sm border-l ${mode === "wipe" ? "bg-neutral-900 text-white" : "bg-white"}`}
                onClick={() => setMode("wipe")}
              >
                Wipe（境界スライド）
              </button>
            </div>

            <p className="mt-4 mb-2 text-sm font-semibold">向き</p>
            <div className="inline-flex rounded-xl overflow-hidden border">
              <button
                className={`px-3 py-2 text-sm ${orientation === "horizontal" ? "bg-neutral-900 text-white" : "bg-white"}`}
                onClick={() => setOrientation("horizontal")}
              >
                横（左右）
              </button>
              <button
                className={`px-3 py-2 text-sm border-l ${orientation === "vertical" ? "bg-neutral-900 text-white" : "bg-white"}`}
                onClick={() => setOrientation("vertical")}
              >
                縦（上下）
              </button>
            </div>
          </div>

          <div className="col-span-1 p-4 bg-white rounded-2xl shadow-sm border">
            <p className="mb-2 text-sm font-semibold">バー（スライダー）</p>
            {orientation === "horizontal" ? (
              <input
                type="range"
                min={0}
                max={100}
                value={reveal}
                onChange={(e) => setReveal(parseInt(e.target.value))}
                className="w-full"
              />
            ) : (
              <div className="h-40 flex items-center justify-center">
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={reveal}
                  onChange={(e) => setReveal(parseInt(e.target.value))}
                  className="w-40 rotate-[-90deg]"
                />
              </div>
            )}
            <div className="mt-2 text-sm text-neutral-600">{Math.round(reveal)}%</div>
            <p className="mt-3 text-xs text-neutral-500">
              画像上をドラッグ/スワイプしても操作できます。
            </p>
          </div>
        </section>

        {/* プレビュー */}
        <section className="bg-white rounded-2xl shadow-sm border p-2 md:p-4">
          <div
            ref={containerRef}
            className="relative w-full h-[60vh] md:h-[70vh] bg-neutral-200 rounded-xl overflow-hidden touch-none select-none"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
          >
            {/* 背面（A） */}
            {img1 ? (
              <img
                src={img1}
                alt="A"
                className="absolute inset-0 w-full h-full object-contain"
                draggable={false}
              />
            ) : (
              <Placeholder label="画像A" />
            )}

            {/* 前面（B） */}
            {img2 ? (
              mode === "crossfade" ? (
                <img
                  src={img2}
                  alt="B"
                  style={{ opacity: reveal / 100 }}
                  className="absolute inset-0 w-full h-full object-contain"
                  draggable={false}
                />
              ) : (
                // wipe
                <div
                  className={`absolute inset-0 ${orientation === "vertical" ? "flex items-end" : ""}`}
                >
                  <div
                    className={`relative overflow-hidden ${orientation === "horizontal" ? "h-full" : "w-full"}`}
                    style={wipeOverlayStyle}
                  >
                    <img
                      src={img2}
                      alt="B"
                      className="absolute inset-0 w-full h-full object-contain"
                      draggable={false}
                    />
                  </div>

                  {/* 仕切り線 */}
                  <div
                    className={`absolute bg-white/80 ${orientation === "horizontal" ? "w-0.5" : "h-0.5"}`}
                    style={dividerPosStyle}
                  />

                  {/* ハンドル */}
                  <div
                    className="absolute w-7 h-7 rounded-full bg-neutral-900 text-white flex items-center justify-center shadow-md"
                    style={handlePosStyle}
                  >
                    {orientation === "horizontal" ? (
                      <span className="text-xs">↔</span>
                    ) : (
                      <span className="text-xs">↕</span>
                    )}
                  </div>
                </div>
              )
            ) : (
              !img1 && <Placeholder label="画像B" />
            )}

            {/* ガイド */}
            {!hasBoth && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="px-4 py-2 bg-black/60 text-white rounded-lg text-sm">
                  まずは2枚の画像をアップロードしてください。
                </div>
              </div>
            )}
          </div>
        </section>

        {/* フッター操作（初期化など） */}
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            className="px-3 py-2 text-sm rounded-xl bg-neutral-100 hover:bg-neutral-200 border"
            onClick={() => setReveal(50)}
          >
            50%に戻す
          </button>
          <button
            className="px-3 py-2 text-sm rounded-xl bg-neutral-100 hover:bg-neutral-200 border"
            onClick={() => {
              setImg1(null);
              setImg2(null);
              setReveal(50);
            }}
          >
            画像をクリア
          </button>
        </div>

        <div className="mt-6 text-xs text-neutral-500">
          * 本ツールはクライアントサイドのみで動作します（画像は外部送信されません）。
        </div>
      </div>
    </div>
  );
}

function Placeholder({ label }: { label: string }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="flex items-center gap-2 text-neutral-500">
        <div className="w-10 h-10 rounded-xl bg-neutral-300" />
        <div>
          <div className="text-sm font-medium">{label}</div>
          <div className="text-xs">画像を選択してください</div>
        </div>
      </div>
    </div>
  );
}
